Doesn't run with standard compiling. works on Visual Studio with all c/c++ stuff installed.
easiest to create c++ VS project and copy paste files/code over. Also seen success with clean then build solution.

if save file gets corrupted delete the .bin file in RPG/RPG.
see "how to use.txt" file in RPG/RPG/game backups for instructions on switching save files.

RPG Vx.x.x.zip has a compressed version of the debug folder to use when creatign a project to run this.

If your trying to read the code, im sorry for your suffering. This wasn't originally written to be readable by anyone else and its too much to go fix now. lesson learned. I also started this in 9th grade, so i wasn't really concerned with writing quality code for most of this projects lifetime.
